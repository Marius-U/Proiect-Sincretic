/*
 * PS1.c
 *
 * Created: 10/12/2015 7:19:35 PM
 *  Author: Marius
 */ 


#include <avr/io.h>
#define F_CPU 16000000UL
#include <avr/interrupt.h>
#include <util/delay.h>
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\init.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\segDisplay.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\util.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\uart.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\adc.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\virtualTimers.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\eeprom.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\pid.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\scheduler.h"

#define K_P     1.00
#define K_I     0.01
#define K_D     0.0001

pidData_t pidData;

int main(void)
{	
	//initVirtualTimers();
	//initDisplay();
	//initButtonISR();
	//initLeds();
//	adcInit();
	//uart_init();
	//initPWM();
	//pid_Init(K_P * SCALING_FACTOR, K_I * SCALING_FACTOR , K_D * SCALING_FACTOR , &pidData);
	//initPeriodical();
	
	DDRB = 0x22u; // PB1 si PB5 output;
	
	 while(1)
    {	
		_delay_ms(3000);
		PORTB |= 0x22u;
		_delay_ms(3000);
		PORTB &= 0xDDu;
		
    }
}

