/*
 * scheduler.c
 *
 * Created: 11/1/2015 7:46:33 PM
 *  Author: Marius
 */ 
#include <avr/io.h>
#define F_CPU 16000000UL
#include <avr/interrupt.h>
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\init.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\segDisplay.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\util.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\uart.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\adc.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\eeprom.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\scheduler.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\virtualTimers.h"
#include "E:\Stuff\Faculta\AN_III\AN_III_sem_II\PS2\PS1\PS1\Header\pid.h"

float prescTemp ;
volatile uint16_t count;
uint8_t ledMode;
uint8_t flags[10] = {0,0,0,0,0,0,0,0,0,0};
float sum = 0x00;
float temp = 0x0000f;
uint8_t  tempCount;
	
volatile uint8_t buttonCount;
volatile uint16_t distPWM;
volatile uint16_t distSenzor;
volatile uint16_t dist;
volatile uint8_t connected;
int error;
int turatie = 100u;

void scheduler(void)
{
	if(count == 1000)
	{			
		//set mode for LED_1
		count = 0x0000u;
	}
	if((count % 40 == 0) &&(count >=40))
	{	
			distSenzor = adcRead(DIST_SENZOR);
			distPWM    = (uint16_t)((float)adcRead(REFERINCE)/(float)(4.452173)); //230 top
			dist = distSenzor - 350;
			
			turatie = pid_Controller(distPWM, dist, &pidData);
			OCR0B = turatie;
	}
	if((count % 5 == 0) && (count >= 5))
	{
	}
	 if((count % 10 == 0) && (count >= 10))
	{
	}
	 if(count % 20 == 0)
	{
	}
	if((count % 100 == 0) && (count > 100))
	{
		if(connected)
		{	
			adc_printValue(distPWM/10);
			uart_transmit(' ');
			adc_printValue(dist/10);
			uart_print("\r\n");
		}	
	}

		//checkVirtualTimers();
		
}
void checkVirtualTimers()
{
	uint8_t index = 0x00u;
	
	while(10 > index)
	{
		if(timers[index].timerStarted)
		{
			if (timers[index].period)
			{
				timers[index].period -= 0x01u;
			}
			else if((TIMER_EXPIRED == timers[index].period) && (0x00u != timers[index].f))
			{
				//if timer expired call the callback function
				timers[index].f();
				timers[index].timerStarted = TIMER_EXPIRED;
			}
			else if(TIMER_EXPIRED == timers[index].period)
			{
				//if timer expired and there is no callback function, set action flag
				flags[timers[index].module] = FLAG_SET;
				timers[index].timerStarted = TIMER_EXPIRED;
			}
		}
		index += 0x01u;
	}
}

void incrementDisplay()
{
	if (PINC & (0x01u))
	{
		//Button was pressed!
		buttonCount = eeprom_read(0x00u);
		if(buttonCount < 10)
		{
			buttonCount++;
			eeprom_write(0x00u,buttonCount);
			display(buttonCount);
		}
		else
		{
			buttonCount = 0x00;
			eeprom_write(0x00u, buttonCount);
			display(buttonCount);
		}
		startNewVirtualTimer(3000,BUTTON_MODULE,resetDisplay,1);
	}
	else
	{
		stopVirtualTimer(BUTTON_MODULE,resetDisplay,1);
	}
}
void resetDisplay()
{
		if (PINC & (0x01u))
		{
			buttonCount = 0x00u;
			eeprom_write(0x00u,buttonCount);
			display(buttonCount);
		}
}